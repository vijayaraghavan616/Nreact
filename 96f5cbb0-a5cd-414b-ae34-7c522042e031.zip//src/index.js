import React from "react";
import ReactDOM from "react-dom";

const date = new Date(11, 2, 25, 1);
const currentTime = date.getHours();
const currentMin = date.getMinutes();
const currentSec = date.getSeconds();

console.log(currentTime);
let greetings;

const customStyle = {
  color: "",
};

if (currentTime < 12) {
  greetings = "Good Morning";
  customStyle.color = "red";
} else if (currentTime < 18) {
  greetings = "Good Afternoon";
  customStyle.color = "green";
} else {
  greetings = "Good Night";
  customStyle.color = "blue";
}

ReactDOM.render(
  <div lang="en">
    <h1 className="head" style={customStyle}>
      {greetings}
    </h1>
    <h2>
      Current Time: {currentTime}:{currentMin}:{currentSec}
    </h2>
  </div>,
  document.getElementById("root")
);
