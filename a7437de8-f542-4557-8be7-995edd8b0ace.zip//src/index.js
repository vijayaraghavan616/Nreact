import React from "react";
import ReactDOM from "react-dom";

const currentDate = new Date("2023, 1, 7");
const year = currentDate.getFullYear();

ReactDOM.render(
  <div>
    <p>COPY RIGHT {year}</p>
  </div>,
  document.getElementById("root")
);
