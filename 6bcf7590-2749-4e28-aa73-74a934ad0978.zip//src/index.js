import React from "react";
import ReactDOM from "react-dom";
import {add,subtract,multiply,divide} from "./calc";

ReactDOM.render(
    <ul>
        <li>{add(1,2)}</li>
        <li>{subtract(3,4)}</li>
        <li>{multiply(4,5)}</li>
        <li>{divide(4,7)}</li>
    </ul>,
    document.getElementById("root")
 ) ;

