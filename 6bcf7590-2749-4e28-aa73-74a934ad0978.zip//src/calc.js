import React from "react";
import ReactDom from "react-dom";

function add(a, b) {
  return a + b;
}

function subtract(a, b) {
  return a - b;
}

function multiply(a, b) {
  return a * b;
}

function divide(a, b) {
  return a / b;
}

export { add, subtract, multiply, divide };
